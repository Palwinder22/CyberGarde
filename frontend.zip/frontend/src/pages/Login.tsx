import React from 'react';

const Login = () => {
  return (
    <div className="text-white">Login Page</div>
  );
};

export default Login; // ✅ This is what your error is complaining about
